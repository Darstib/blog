x = [8.22, 7.41, 6.88, 5.49, 5.20];
y = [1.799, 1.415, 1.213, 0.666, 0.529];

% 计算线性回归系数
p = polyfit(x, y, 1); % p(1)是斜率，p(2)是截距



x_fit = linspace(0, 10, 200); % 100个点

% 计算对应的 y 值
y_fit = polyval(p, x_fit); 

% 绘制散点图
figure;
scatter(x, y, 'filled', 'MarkerFaceColor', 'b');
hold on;



% 绘制回归线
plot(x_fit, y_fit, 'r-', 'LineWidth', 2);

% 添加标题和标签
title('线性回归示例');
xlabel('频率mu/10 -14)Hz');
ylabel('截止电压U0/v');
legend('数据点', '回归线');

% 显示网格
grid on;

% 释放图形
hold off;
